Sample configuration files for:

SystemD: almexd.service
Upstart: almexd.conf
OpenRC:  almexd.openrc
         almexd.openrcconf
CentOS:  almexd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
